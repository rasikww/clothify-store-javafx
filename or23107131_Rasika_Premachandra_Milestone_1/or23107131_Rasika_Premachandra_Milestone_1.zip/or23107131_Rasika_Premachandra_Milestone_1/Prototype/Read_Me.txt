Prototype-views folder has the prepared prototype windows as png files.

Visit following link for a live demo.


https://app.quant-ux.com/#/test.html?h=a2aa10ar2eDKONxBNhoGA8zZ8Mn5uB7KNXG9zpWqmsoUeKtb5XuT1MBFjite&ln=en

Rasika Premachandra
or23107131
